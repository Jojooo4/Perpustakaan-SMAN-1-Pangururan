<?php $__env->startSection('title', 'Dashboard Petugas'); ?>
<?php $__env->startSection('page-title', 'Dashboard Petugas'); ?>

<?php $__env->startSection('content'); ?>
<div class="hero-card mb-5">
    <span class="hero-badge"><i class="fas fa-shield-alt"></i> AREA PETUGAS</span>
    <h2>Dashboard Operasional</h2>
    <p>Pantau statistik utama perpustakaan dan jalankan proses transaksi dengan akses cepat dari satu layar.</p>
    <div class="hero-actions">
        <a href="<?php echo e(route('petugas.transaksi.index')); ?>" class="btn btn-accent">
            <i class="fas fa-plus"></i>
            Pinjam Buku
        </a>
        <a href="<?php echo e(route('petugas.transaksi.index')); ?>" class="btn btn-accent-outline">
            <i class="fas fa-undo"></i>
            Kembalikan Buku
        </a>
        <a href="<?php echo e(route('petugas.buku.index')); ?>" class="btn btn-accent-outline">
            <i class="fas fa-book"></i>
            Lihat Buku
        </a>
        <a href="<?php echo e(route('petugas.perpanjangan.index')); ?>" class="btn btn-accent-outline">
            <i class="fas fa-clock"></i>
            Perpanjangan
        </a>
    </div>
</div>

<div class="dash-grid mb-4">
    <div class="stat-card">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <p>Peminjaman Aktif</p>
                <h3><?php echo e($peminjamanAktif ?? 0); ?></h3>
            </div>
            <div class="stat-icon icon-warning">
                <i class="fas fa-clock"></i>
            </div>
        </div>
    </div>

    <div class="stat-card">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <p>Total Buku</p>
                <h3><?php echo e($totalBuku ?? 0); ?></h3>
            </div>
            <div class="stat-icon icon-primary">
                <i class="fas fa-book"></i>
            </div>
        </div>
    </div>

    <div class="stat-card">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <p>Pengunjung Aktif</p>
                <h3><?php echo e($pengunjungAktif ?? 0); ?></h3>
            </div>
            <div class="stat-icon icon-secondary">
                <i class="fas fa-users"></i>
            </div>
        </div>
    </div>
</div>

<div class="welcome-panel">
    <i class="fas fa-user-tie"></i>
    <h5 class="mt-3">Selamat Datang, <?php echo e(auth()->user()->nama ?? 'Petugas'); ?>!</h5>
    <p class="mb-0">Gunakan menu navigasi untuk mengelola perpustakaan</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.petugas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUBES MSBD\BranchSendiriMSBD\Perpustakaan-SMAN-1-Pangururan\resources\views/petugas/dashboard.blade.php ENDPATH**/ ?>