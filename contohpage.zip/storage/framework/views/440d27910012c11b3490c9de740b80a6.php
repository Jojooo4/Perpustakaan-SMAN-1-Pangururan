<?php $__env->startSection('title', 'Laporan Denda'); ?>
<?php $__env->startSection('page-title', 'Laporan Denda'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-3">
    <div class="col-md-6">
        <div class="stat-card">
            <h6 class="mb-0">Total Denda Belum Lunas</h6>
            <h3 class="mb-0 text-danger">Rp <?php echo e(number_format($totalDendaBelumLunas ?? 0, 0, ',', '.')); ?></h3>
        </div>
    </div>
    <div class="col-md-3">
        <select class="form-select" id="statusFilter">
            <option value="">Semua Status</option>
            <option value="lunas">Lunas</option>
            <option value="belum">Belum Lunas</option>
        </select>
    </div>
    <div class="col-md-3">
        <a href="<?php echo e(route('denda.export', request()->query())); ?>" class="btn btn-success w-100 mb-2">
            <i class="fas fa-file-excel me-2"></i>Export Excel
        </a>
        <a href="<?php echo e(route('denda.export-pdf')); ?>" class="btn btn-danger w-100">
            <i class="fas fa-file-pdf me-2"></i>Export PDF
        </a>
    </div>
</div>

<div class="stat-card">
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Peminjam</th>
                    <th>Buku</th>
                    <th>Jatuh Tempo</th>
                    <th>Kembali</th>
                    <th>Terlambat</th>
                    <th>Denda</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $denda ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $jatuhTempo = $d->tanggal_jatuh_tempo ? \Carbon\Carbon::parse($d->tanggal_jatuh_tempo) : null;
                    $kembali = $d->tanggal_kembali ? \Carbon\Carbon::parse($d->tanggal_kembali) : now();
                    $hariTerlambat = $jatuhTempo ? max(0, $kembali->diffInDays($jatuhTempo, false) * -1) : 0;
                ?>
                <tr>
                    <td><?php echo e($d->id_peminjaman); ?></td>
                    <td><strong><?php echo e($d->user->nama ?? '-'); ?></strong></td>
                    <td><?php echo e($d->asetBuku->buku->judul ?? '-'); ?></td>
                    <td><?php echo e($jatuhTempo ? $jatuhTempo->format('d/m/Y') : '-'); ?></td>
                    <td><?php echo e($d->tanggal_kembali ? $kembali->format('d/m/Y') : '-'); ?></td>
                    <td><span class="badge bg-warning"><?php echo e($hariTerlambat); ?> hari</span></td>
                    <td class="fw-bold text-danger">Rp <?php echo e(number_format($d->denda, 0, ',', '.')); ?></td>
                    <td>
                        <?php if($d->denda_lunas ?? false): ?>
                            <span class="badge bg-success">Lunas</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Belum Lunas</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(!($d->denda_lunas ?? false)): ?>
                            <button class="btn btn-success btn-sm" onclick="markPaid(<?php echo e($d->id_peminjaman); ?>)">
                                <i class="fas fa-check me-1"></i>Lunas
                            </button>
                        <?php else: ?>
                            <button class="btn btn-secondary btn-sm" disabled>
                                <i class="fas fa-check me-1"></i>Sudah Lunas
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center text-muted py-4">
                        <i class="fas fa-money-bill-wave fa-3x mb-3 d-block" style="opacity: 0.3;"></i>
                        Tidak ada data denda
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function markPaid(id) {
    if(confirm('Tandai denda sebagai lunas?')) {
        let form = document.createElement('form');
        form.method = 'POST';
        form.action = `/admin/fines/${id}/mark-paid`;
        
        let csrf = document.createElement('input');
        csrf.type = 'hidden';
        csrf.name = '_token';
        csrf.value = '<?php echo e(csrf_token()); ?>';
        form.appendChild(csrf);
        
        document.body.appendChild(form);
        form.submit();
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUBES MSBD\BranchSendiriMSBD\Perpustakaan-SMAN-1-Pangururan\resources\views/admin/laporan_denda.blade.php ENDPATH**/ ?>