

<?php $__env->startSection('title', 'Permintaan Perpanjangan'); ?>
<?php $__env->startSection('page-title', 'Permintaan Perpanjangan'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.permintaan_perpanjangan', ['__inherit' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.petugas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUBES MSBD\BranchSendiriMSBD\Perpustakaan-SMAN-1-Pangururan\resources\views/petugas/permintaan_perpanjangan.blade.php ENDPATH**/ ?>