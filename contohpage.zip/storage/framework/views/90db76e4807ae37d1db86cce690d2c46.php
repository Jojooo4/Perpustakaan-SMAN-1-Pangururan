

<?php $__env->startSection('title', 'Request Peminjaman'); ?>
<?php $__env->startSection('page-title', 'Request Peminjaman Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-3">
    <div class="col-md-6">
        <div class="stat-card">
            <h6 class="mb-0">Request Pending</h6>
            <h3 class="mb-0 text-warning"><?php echo e($pendingCount); ?></h3>
        </div>
    </div>
    <div class="col-md-3">
        <select class="form-select" onchange="window.location.href='?status='+this.value">
            <option value="">Semua Status</option>
            <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
            <option value="disetujui" <?php echo e(request('status') == 'disetujui' ? 'selected' : ''); ?>>Disetujui</option>
            <option value="ditolak" <?php echo e(request('status') == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
        </select>
    </div>
</div>

<div class="stat-card">
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Peminjam</th>
                    <th>Buku</th>
                    <th>Tanggal Request</th>
                    <th>Status</th>
                    <th>Diproses Oleh</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($req->id_request); ?></td>
                    <td><strong><?php echo e($req->user->nama ?? '-'); ?></strong></td>
                    <td>
                        <?php if($req->buku): ?>
                            <?php echo e($req->buku->judul); ?>

                        <?php else: ?>
                            <span class="text-danger">Buku tidak ditemukan (ID: <?php echo e($req->id_buku); ?>)</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($req->tanggal_request ? \Carbon\Carbon::parse($req->tanggal_request)->format('d/m/Y H:i') : '-'); ?></td>
                    <td>
                        <?php if($req->status == 'pending'): ?>
                            <span class="badge bg-warning">Pending</span>
                        <?php elseif($req->status == 'disetujui'): ?>
                            <span class="badge bg-success">Disetujui</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Ditolak</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($req->diproses_oleh): ?>
                            <?php echo e($req->diproses->nama ?? '-'); ?>

                            <br><small class="text-muted"><?php echo e($req->tanggal_diproses ? \Carbon\Carbon::parse($req->tanggal_diproses)->format('d/m/Y H:i') : ''); ?></small>
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($req->status == 'pending'): ?>
                            <?php if($req->buku): ?>
                                <button class="btn btn-success btn-sm me-1" onclick="showApproveModal(<?php echo e($req->id_request); ?>, '<?php echo e(addslashes($req->user->nama)); ?>', '<?php echo e(addslashes($req->buku->judul)); ?>', '<?php echo e($req->tanggal_request ? \Carbon\Carbon::parse($req->tanggal_request)->format('d/m/Y H:i') : '-'); ?>')">
                                    <i class="fas fa-check me-1"></i>Approve
                                </button>
                                <button class="btn btn-danger btn-sm" onclick="showRejectModal(<?php echo e($req->id_request); ?>, '<?php echo e(addslashes($req->buku->judul)); ?>')">
                                    <i class="fas fa-times me-1"></i>Reject
                                </button>
                            <?php else: ?>
                                <span class="text-danger small"><i class="fas fa-exclamation-triangle"></i> Data buku hilang</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($req->status == 'ditolak' && $req->catatan_admin): ?>
                                <button class="btn btn-sm btn-secondary" onclick="showReason('<?php echo e(addslashes($req->catatan_admin)); ?>')">
                                    <i class="fas fa-info-circle"></i> Lihat Alasan
                                </button>
                            <?php else: ?>
                                <span class="text-muted">Sudah diproses</span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted py-4">
                        <i class="fas fa-inbox fa-3x mb-3 d-block" style="opacity: 0.3;"></i>
                        Tidak ada request peminjaman
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <?php echo e($requests->appends(request()->query())->links()); ?>

</div>

<!-- Approve Modal -->
<div class="modal fade" id="approveModal" tabindex="-1" aria-labelledby="approveModalLabel" aria-hidden="true" style="z-index: 1055;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="approveForm" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="approveModalLabel">
                        <i class="fas fa-check-circle me-2"></i>Konfirmasi Approve Peminjaman
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Pastikan data berikut sudah benar sebelum menyetujui peminjaman.
                    </div>
                    
                    <div class="mb-3">
                        <label class="fw-bold text-muted small">Peminjam:</label>
                        <p class="mb-0" id="approveBorrowerName"></p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="fw-bold text-muted small">Buku:</label>
                        <p class="mb-0" id="approveBookTitle"></p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="fw-bold text-muted small">Tanggal Request:</label>
                        <p class="mb-0" id="approveRequestDate"></p>
                    </div>
                    
                    <div class="alert alert-warning mb-0">
                        <i class="fas fa-calendar-check me-2"></i>
                        <small>Periode peminjaman: <strong>7 hari</strong> dari hari ini</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>Batal
                    </button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check me-1"></i>Ya, Setujui Peminjaman
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true" style="z-index: 1055;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="rejectForm" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Tolak Request Peminjaman</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Buku: <strong id="rejectBookTitle"></strong></p>
                    <div class="mb-3">
                        <label class="form-label">Alasan Penolakan <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="catatan_admin" rows="4" required 
                                  placeholder="Masukkan alasan penolakan..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger">Tolak Request</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reason Modal -->
<div class="modal fade" id="reasonModal" tabindex="-1" aria-labelledby="reasonModalLabel" aria-hidden="true" style="z-index: 1055;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="reasonModalLabel">Alasan Penolakan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p id="reasonText"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function showApproveModal(id, borrowerName, bookTitle, requestDate) {
    document.getElementById('approveBorrowerName').textContent = borrowerName;
    document.getElementById('approveBookTitle').textContent = bookTitle;
    document.getElementById('approveRequestDate').textContent = requestDate;
    document.getElementById('approveForm').action = `/petugas/request-peminjaman/${id}/approve`;
    new bootstrap.Modal(document.getElementById('approveModal')).show();
}

function showRejectModal(id, bookTitle) {
    document.getElementById('rejectBookTitle').textContent = bookTitle;
    document.getElementById('rejectForm').action = `/petugas/request-peminjaman/${id}/reject`;
    new bootstrap.Modal(document.getElementById('rejectModal')).show();
}

function showReason(reason) {
    document.getElementById('reasonText').textContent = reason;
    new bootstrap.Modal(document.getElementById('reasonModal')).show();
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.petugas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUBES MSBD\BranchSendiriMSBD\Perpustakaan-SMAN-1-Pangururan\resources\views/petugas/request_peminjaman.blade.php ENDPATH**/ ?>