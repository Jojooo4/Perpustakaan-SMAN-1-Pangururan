<?php $__env->startSection('title', 'Log Aktivitas'); ?>
<?php $__env->startSection('page-title', 'Log Aktivitas'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-3">
    <div class="col-md-3">
        <div class="stat-card">
            <h6 class="mb-0 text-muted">Total Aktivitas</h6>
            <h3 class="mb-0"><?php echo e($stats['total']); ?></h3>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <h6 class="mb-0 text-muted">Hari Ini</h6>
            <h3 class="mb-0 text-primary"><?php echo e($stats['today']); ?></h3>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <h6 class="mb-0 text-muted">Minggu Ini</h6>
            <h3 class="mb-0 text-success"><?php echo e($stats['this_week']); ?></h3>
        </div>
    </div>
</div>

<div class="card-custom p-4">
    <h5 class="mb-3"><i class="fas fa-history me-2"></i>Riwayat Aktivitas</h5>
    
    <!-- Filters -->
    <form method="GET" class="row g-3 mb-3">
        <div class="col-md-3">
            <label class="form-label small">Tabel</label>
            <select name="table" class="form-select form-select-sm">
                <option value="">Semua</option>
                <option value="peminjaman" <?php echo e(request('table') == 'peminjaman' ? 'selected' : ''); ?>>Peminjaman</option>
                <option value="request_peminjaman" <?php echo e(request('table') == 'request_peminjaman' ? 'selected' : ''); ?>>Request Peminjaman</option>
                <option value="request_perpanjangan" <?php echo e(request('table') == 'request_perpanjangan' ? 'selected' : ''); ?>>Perpanjangan</option>
                <option value="buku" <?php echo e(request('table') == 'buku' ? 'selected' : ''); ?>>Buku</option>
                <option value="users" <?php echo e(request('table') == 'users' ? 'selected' : ''); ?>>Users</option>
            </select>
        </div>
        <div class="col-md-2">
            <label class="form-label small">Operasi</label>
            <select name="operation" class="form-select form-select-sm">
                <option value="">Semua</option>
                <option value="insert" <?php echo e(request('operation') == 'insert' ? 'selected' : ''); ?>>Insert</option>
                <option value="update" <?php echo e(request('operation') == 'update' ? 'selected' : ''); ?>>Update</option>
                <option value="delete" <?php echo e(request('operation') == 'delete' ? 'selected' : ''); ?>>Delete</option>
            </select>
        </div>
        <div class="col-md-2">
            <label class="form-label small">User</label>
            <select name="user_id" class="form-select form-select-sm">
                <option value="">Semua</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id_user); ?>" <?php echo e(request('user_id') == $user->id_user ? 'selected' : ''); ?>><?php echo e($user->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2">
            <label class="form-label small">Dari</label>
            <input type="date" name="date_from" class="form-control form-control-sm" value="<?php echo e(request('date_from')); ?>">
        </div>
        <div class="col-md-2">
            <label class="form-label small">Sampai</label>
            <input type="date" name="date_to" class="form-control form-control-sm" value="<?php echo e(request('date_to')); ?>">
        </div>
        <div class="col-md-1">
            <label class="form-label small">&nbsp;</label>
            <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-filter"></i></button>
        </div>
    </form>
    
    <!-- Table -->
    <div class="table-responsive">
        <table class="table table-hover table-sm">
            <thead class="table-dark">
                <tr>
                    <th width="50">ID</th>
                    <th width="120">Waktu</th>
                    <th width="120">User</th>
                    <th width="100">Tabel</th>
                    <th width="80">Operasi</th>
                    <th>Deskripsi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($log->id_log); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($log->timestamp)->format('d/m/Y H:i')); ?></td>
                    <td><strong><?php echo e($log->username); ?></strong></td>
                    <td><span class="badge bg-secondary"><?php echo e($log->nama_tabel); ?></span></td>
                    <td>
                        <?php if($log->operasi == 'insert'): ?>
                            <span class="badge bg-success">INSERT</span>
                        <?php elseif($log->operasi == 'update'): ?>
                            <span class="badge bg-warning text-dark">UPDATE</span>
                        <?php else: ?>
                            <span class="badge bg-danger">DELETE</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($log->deskripsi); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center py-4">
                        <i class="fas fa-inbox fa-3x text-muted mb-3 d-block" style="opacity: 0.3;"></i>
                        <span class="text-muted">Tidak ada log aktivitas</span>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <?php echo e($logs->appends(request()->query())->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUBES MSBD\BranchSendiriMSBD\Perpustakaan-SMAN-1-Pangururan\resources\views/admin/log_aktivitas.blade.php ENDPATH**/ ?>