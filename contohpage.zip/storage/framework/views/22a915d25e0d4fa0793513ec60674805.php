<?php $__env->startSection('title', 'Permintaan Perpanjangan'); ?>
<?php $__env->startSection('page-title', 'Permintaan Perpanjangan'); ?>

<?php $__env->startSection('content'); ?>
<div class="stat-card">
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Peminjam</th>
                    <th>Buku</th>
                    <th>Jatuh Tempo Lama</th>
                    <th>Jatuh Tempo Baru</th>
                    <th>Alasan</th>
                    <th>Tanggal Request</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $requests ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($req->id_request); ?></td>
                    <td><strong><?php echo e($req->peminjaman->user->nama ?? '-'); ?></strong></td>
                    <td><?php echo e($req->peminjaman->asetBuku->buku->judul ?? '-'); ?></td>
                    <td><?php echo e($req->peminjaman->tanggal_jatuh_tempo ? \Carbon\Carbon::parse($req->peminjaman->tanggal_jatuh_tempo)->format('d/m/Y') : '-'); ?></td>
                    <td><?php echo e($req->tanggal_perpanjangan_baru ? \Carbon\Carbon::parse($req->tanggal_perpanjangan_baru)->format('d/m/Y') : '-'); ?></td>
                    <td><?php echo e($req->catatan ?? '-'); ?></td>
                    <td><?php echo e($req->tanggal_request ? \Carbon\Carbon::parse($req->tanggal_request)->format('d/m/Y H:i') : '-'); ?></td>
                    <td>
                        <?php if($req->status == 'pending'): ?>
                            <span class="badge bg-warning">Pending</span>
                        <?php elseif($req->status == 'disetujui'): ?>
                            <span class="badge bg-success">Disetujui</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Ditolak</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($req->status == 'pending'): ?>
                            <div class="btn-group btn-group-sm">
                                <button class="btn btn-success" onclick="approve(<?php echo e($req->id_request); ?>)">
                                    <i class="fas fa-check"></i> Setuju
                                </button>
                                <button class="btn btn-danger" onclick="reject(<?php echo e($req->id_request); ?>)">
                                    <i class="fas fa-times"></i> Tolak
                                </button>
                            </div>
                        <?php else: ?>
                            <span class="text-muted">Sudah diproses</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center text-muted py-4">
                        <i class="fas fa-clock fa-3x mb-3 d-block" style="opacity: 0.3;"></i>
                        Tidak ada permintaan perpanjangan
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function approve(id) {
    if(confirm('Setujui permintaan perpanjangan ini?')) {
        let form = document.createElement('form');
        form.method = 'POST';
        form.action = `/permintaan_perpanjangan/${id}/approve`;
        
        let csrf = document.createElement('input');
        csrf.type = 'hidden';
        csrf.name = '_token';
        csrf.value = '<?php echo e(csrf_token()); ?>';
        form.appendChild(csrf);
        
        document.body.appendChild(form);
        form.submit();
    }
}

function reject(id) {
    let reason = prompt('Alasan penolakan (opsional):');
    if(reason !== null) {
        let form = document.createElement('form');
        form.method = 'POST';
        form.action = `/permintaan_perpanjangan/${id}/reject`;
        
        let csrf = document.createElement('input');
        csrf.type = 'hidden';
        csrf.name = '_token';
        csrf.value = '<?php echo e(csrf_token()); ?>';
        form.appendChild(csrf);
        
        if(reason) {
            let reasonInput = document.createElement('input');
            reasonInput.type = 'hidden';
            reasonInput.name = 'catatan_admin';
            reasonInput.value = reason;
            form.appendChild(reasonInput);
        }
        
        document.body.appendChild(form);
        form.submit();
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUBES MSBD\BranchSendiriMSBD\Perpustakaan-SMAN-1-Pangururan\resources\views/admin/permintaan_perpanjangan.blade.php ENDPATH**/ ?>