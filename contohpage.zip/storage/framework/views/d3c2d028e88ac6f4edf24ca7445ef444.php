

<?php $__env->startSection('title', 'Manajemen Buku'); ?>
<?php $__env->startSection('page-title', 'Manajemen Buku'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<style>
    .book-cover-preview { width: 60px; height: 80px; object-fit: cover; border-radius: 4px; }
    .image-upload-preview { max-width: 200px; max-height: 250px; margin-top: 10px; border-radius: 8px; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.manajemen_buku', ['__inherit' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.petugas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUBES MSBD\BranchSendiriMSBD\Perpustakaan-SMAN-1-Pangururan\resources\views/petugas/manajemen_buku.blade.php ENDPATH**/ ?>