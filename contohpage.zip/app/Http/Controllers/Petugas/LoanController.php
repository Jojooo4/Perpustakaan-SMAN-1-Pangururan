<?php

namespace App\Http\Controllers\Petugas;

use App\Http\Controllers\Admin\LoanController as AdminLoanController;

class LoanController extends AdminLoanController
{
    // Inherit from Admin LoanController
}
