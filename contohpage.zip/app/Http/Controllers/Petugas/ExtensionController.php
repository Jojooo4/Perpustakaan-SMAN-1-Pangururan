<?php

namespace App\Http\Controllers\Petugas;

use App\Http\Controllers\Admin\ExtensionController as AdminExtensionController;

class ExtensionController extends AdminExtensionController
{
    // Inherit from Admin ExtensionController
}
