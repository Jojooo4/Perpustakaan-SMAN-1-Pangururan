<?php

namespace App\Http\Controllers\Petugas;

use App\Http\Controllers\Admin\FineController as AdminFineController;

class FineController extends AdminFineController
{
    // Inherit from Admin FineController
}
